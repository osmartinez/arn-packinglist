package com.arneplant.packinglist.ui_interface


interface BuscadorFragmentDelegate {
    fun buscadorFragmentCodigoEscaneado(msg: String)
}