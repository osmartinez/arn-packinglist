package com.arneplant.packinglist.ui_interface

interface LecturaCajaDelegate {
    fun cajaLeida(codigoCaja: String, idPackingList: Int)
}