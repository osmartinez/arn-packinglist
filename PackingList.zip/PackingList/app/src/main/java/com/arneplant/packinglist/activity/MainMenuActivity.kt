package com.arneplant.packinglist.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.arneplant.packinglist.R

class MainMenuActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)
    }
}
