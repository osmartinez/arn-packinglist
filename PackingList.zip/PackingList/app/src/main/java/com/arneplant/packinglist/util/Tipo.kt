package com.arneplant.packinglist.util

enum class Tipo {
    IP,
    Contenedor,
    None,
}